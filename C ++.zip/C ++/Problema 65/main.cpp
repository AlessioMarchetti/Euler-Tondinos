#include <iostream>
#define N 100

using namespace std;

struct Frac
{
    int n;
    int d;
};

Frac sum(Frac,Frac);
Frac inv(Frac);
int gcd(int,int);
int lcm(int,int);
Frac go(int*,int);

int main()
{
    int lt[N];
    lt[0]=2;
    for(int i=1;i<N;i++){
        if(i%3==0||i%3==1) lt[i]=1;
        else lt[i]=2*(i+1)/3;
    }
    Frac r=go(lt,N);
    cout<<r.n;
    return 0;
}
Frac go(int* l,int n)
{
    if(n==0) return {0,1};
    return sum(l[0],inv(go(l+1,n-1)));
}
int gcd(int a,int b)
{
    if(b==0) return a;
    return gcd(b,a%b);
}
int lcm(int a,int b)
{
    return a*b/gcd(a,b);
}
Frac inv(Frac f)
{
    int k=f.d;
    f.d=f.n;
    f.n=k;
    return f;
}
Frac sum(Frac a,Frac b)
{
    Frac r;
    r.d=lcm(a.d,b.d);
    r.n=a.n*r.d/a.d+b.n*r.d/b.d;
    int k=gcd(r.d,r.n);
    r.d/=k;
    r.n/=k;
    return r;
}
