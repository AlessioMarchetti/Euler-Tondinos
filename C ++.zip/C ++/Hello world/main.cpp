#include <iostream>
#include <math.h>
#define N 600851475143
using namespace std;
bool isPrime(unsigned long long);

int main()
{
    unsigned long long i;
    for(i = N; i >= 1; i--){
        if(N%i==0){
            if(isPrime(i)) break;
        }
        cout << i <<endl;
    }
    cout << "RESULT: ";
    cout << i;
    return 0;
}


bool isPrime(unsigned long long n)
{
    unsigned long long i;
    for(i = n-1; i >= 1; i--){
        if(n%i == 0) break;
    }
    return i == 1;
}
