#ifndef LAYH
#define LAYH
#include "Neu.h"
#include "Syn.h"

class Lay
{
    Neu** neu;
    int neuNum;
public:
    Lay(int);
    void addNeu(Neu*);
    Neu** getNeu();
    int getNeuNum();
    void updateWeight();
    void linkWith(Lay*);
    void setInVal(PRE*);
    PRE* returnVal();
    void potential();
    void propagate();
    void computeDeltas(PRE*,PRE);
};
#endif // LAYH
