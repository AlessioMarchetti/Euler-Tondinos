#include "Neu.h"

Neu::Neu(int fid)
{
    id=fid;
    inSynNum=0;
    outSynNum=0;
}
void Neu::addInSyn(Syn* syn)
{
    inSynNum++;
    inSyn[inSynNum]=syn;
}
void Neu::addOutSyn(Syn* syn)
{
    outSynNum++;
    outSyn[outSynNum]=syn;
}
int Neu::getInSynNum()
{
    return inSynNum;
}
int Neu::getOutSynNum()
{
    return outSynNum;
}
Syn** Neu::getInSyn()
{
    return inSyn;
}
Syn** Neu::getOutSyn()
{
    return outSyn;
}
PRE Neu::getInVal()
{
    return inVal;
}
PRE Neu::getOutVal()
{
    return outVal;
}
void Neu::setInVal(PRE k)
{
    inVal=k;
}
void Neu::setOutVal(PRE k)
{
    outVal=k;
}
void Neu::potential()
{
    PRE res=0;
    for(int i=0;i<inSynNum;i++){
        res+=((inSyn[i]->getWeight())*(inSyn[i]->getIn()->getOutVal()));
    }
    inVal=res;
}
void Neu::transfer()
{
    outVal=inVal;//TODO udate transfer function from linear to sigmoid
}
void Neu::computeDelta(PRE* des,PRE lRate)
{
    Syn* s;
    for(int i=0;i<inSynNum;i++){
        s=inSyn[i];
        s->setDelta(-lRate*s->getIn()->getOutVal()*getSigma(des));
    }
}
PRE Neu::getSigma(PRE* des)
{
    if(outSynNum==0){
        return (outVal-des[id])*outVal*(1-outVal);
    }
    PRE res=0;
    Syn* s;
    for(int i=0;i<outSynNum;i++){
        s=outSyn[i];
        res+=s->getWeight()*s->getOut()->getSigma(des);
    }
    res*=outVal*(1-outVal);
    return res;
}
void Neu::upWeight()
{
    Syn* s;
    for(int i=0;i<inSynNum;i++){
        s=inSyn[i];
        s->upWeight();
    }
}














