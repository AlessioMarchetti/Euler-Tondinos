#include "Lay.h"
#include <time.h>
#include <stdlib.h>
#include <cstdlib>
#include <stdio.h>

Lay::Lay(int num)
{
    neuNum=0;
    neu=new Neu*[num]();
    for(int i=0;i<num;i++) addNeu(new Neu(i));
}
void Lay::addNeu(Neu* n)
{
    neuNum++;
    neu[neuNum]=n;
}
Neu** Lay::getNeu()
{
    return neu;
}
int Lay::getNeuNum()
{
    return neuNum;
}
void Lay::updateWeight()
{
    int i;
    Neu* n;
    for(i=0;i<neuNum;i++){
        n=neu[i];
        n->upWeight();
    }
}
void Lay::linkWith(Lay* lay)
{
    int i;
    int j;
    Neu* in;
    Neu* out;
    Syn* syn;

    for(i=0;i<this->neuNum;i++){
        in=this->getNeu()[i];
        for(j=0;j<lay->getNeuNum();j++){
            out=lay->getNeu()[j];
            syn=new Syn(in,out);
            syn->setWeight(getRand());
            out->addInSyn(syn);
            in->addOutSyn(syn);
        }
    }
}
void Lay::setInVal(PRE* vec)
{
    for(int i=0;i<neuNum;i++){
        neu[i]->setInVal(vec[i]);
        neu[i]->setOutVal(vec[i]);
    }
}
PRE* Lay::returnVal()
{
    PRE* r=new PRE[neuNum]();
    for(int i=0;i<neuNum;i++){
        r[i]=neu[i]->getOutVal();
    }
    return r;
}
void Lay::potential()
{
    for(int i=0;i<neuNum;i++){
        neu[i]->potential();
    }
}
void Lay::propagate()
{
    for(int i=0;i<neuNum;i++){
        neu[i]->transfer();
    }
}
void Lay::computeDeltas(PRE* des,PRE lRate)
{
    Neu* n;
    for(int i=0;i<neuNum;i++){
        n=neu[i];
        n->computeDelta(des,lRate);
    }
}


PRE getRand()
{
    static bool first=true;
    if(first){
        srand(time(NULL));
        first=false;
    }
    return ((PRE)rand())/((PRE)RAND_MAX);
}
