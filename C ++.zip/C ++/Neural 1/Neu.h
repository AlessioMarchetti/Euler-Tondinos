#ifndef NEUH
#define NEUH
#include "Syn.h"
#define PRE float
class Syn;
PRE getRand();
class Neu
{
    int id;
    PRE inVal;
    PRE outVal;
    int inSynNum;
    int outSynNum;
    Syn** inSyn;
    Syn** outSyn;
public:
    Neu(int fid);
    void addInSyn(Syn*);
    void addOutSyn(Syn*);
    int getInSynNum();
    int getOutSynNum();
    Syn** getInSyn();
    Syn** getOutSyn();
    PRE getInVal();
    PRE getOutVal();
    void setInVal(PRE);
    void setOutVal(PRE);
    void potential();
    void transfer();//TODO sostitute transfer function
    void computeDelta(PRE*,PRE);
    PRE getSigma(PRE*);
    void upWeight();
};

#endif // NEUH
