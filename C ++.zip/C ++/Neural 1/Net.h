#ifndef NETH
#define NETH
#include "Lay.h"
#define PRE float

class Net
{
public:
    Net(PRE);
    PRE learnRate;
    Lay* input;
    Lay* hidden;
    Lay* output;
    void init(int inN,int hiN,int ouN);
    void frwd(PRE*);
    void bckwrd(PRE*);
    PRE* getOut();
};

#endif // NETH
