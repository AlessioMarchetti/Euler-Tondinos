#include "Syn.h"

Syn::Syn()
{

}
Syn::Syn(Neu* i,Neu* o)
{
    Syn();
    in=i;
    out=o;
}
PRE Syn::getDelta()
{
    return delta;
}
PRE Syn::getWeight()
{
    return weight;
}
void Syn::setDelta(PRE d)
{
    delta=d;
}
void Syn::setWeight(PRE w)
{
    weight=w;
}
Neu* Syn::getIn()
{
    return in;
}
Neu* Syn::getOut()
{
    return out;
}
void Syn::setIn(Neu* neu)
{
    in=neu;
}
void Syn::setOut(Neu* neu)
{
    out=neu;
}
void Syn::upWeight()
{
    weight+=delta;
}
