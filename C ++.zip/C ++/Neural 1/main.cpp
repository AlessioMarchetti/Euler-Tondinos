#include <iostream>
#include "Net.h"

using namespace std;

int main()
{

    Net* n=new Net(0.5);
    n->init(2,4,1);

    float* in=new float[2]();
    float* ou=new float[1]();

    for(int i=0;i<20;i++){
        in[0]=getRand();
        in[1]=getRand();
        ou[0]=in[0]+in[1];
        n->frwd(in);
        n->bckwrd(ou);
    }

    in[0]=0.3;
    in[1]=0.8;
    n->frwd(in);
    float* res=n->getOut();
    cout<<res[0];

    return 0;
}
