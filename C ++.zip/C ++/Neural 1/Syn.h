#ifndef SYNH
#define SYNH
#define PRE float
#include "Neu.h"
class Neu;
class Syn
{
    PRE delta;
    PRE weight;
    Neu* in;
    Neu* out;
public:
    Syn();
    Syn(Neu*,Neu*);
    PRE getDelta();
    PRE getWeight();
    void setDelta(PRE);
    void setWeight(PRE);
    Neu* getIn();
    Neu* getOut();
    void setIn(Neu*);
    void setOut(Neu*);
    void upWeight();
};

#endif // SYNH
