#include "Net.h"

Net::Net(PRE learningRate)
{
    learnRate=learningRate;
}
void Net::init(int a,int b,int c)
{
    input=new Lay(a);
    hidden=new Lay(b);
    output=new Lay(c);
    input->linkWith(hidden);
    hidden->linkWith(output);
}
void Net::frwd(PRE* in)
{
    input->setInVal(in);
    hidden->potential();
    hidden->propagate();
    output->potential();
    output->propagate();
}
void Net::bckwrd(PRE* des)
{
    output->computeDeltas(des,learnRate);
    hidden->computeDeltas(des,learnRate);
    output->updateWeight();
    hidden->updateWeight();
}
PRE* Net::getOut()
{
    return output->returnVal();
}
