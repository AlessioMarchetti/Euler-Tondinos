#include <iostream>
#include <math.h>
#define N 1000000

using namespace std;

int shift(int,int);
bool isPrime(int);
void init();
bool* tab;
int* toArr(int);
int ci(int);
int myPow(int,int);

int main()
{
    init();


    int res=0;
    int c;
    bool b;
    for(int i=2;i<=N;i++){
        c=ci(i);
        b=true;
        for(int j=0;j<c;j++){
            if(i==0)b=false;
            b&=isPrime(shift(i,j));
            if(!b) break;
        }
        if(b) res++;
    }
    res++;
    cout<<"\n\n\n"<<endl<<"And the result is:\n";
    cout<<res<<"\n\n\n";
    return 0;
}
int shift(int n,int tt)
{
    int len=ci(n)-1;
    int* arr=toArr(n);
    for(int i=0;i<=len;i++) if(arr[i]%2==0){
        delete arr;
        return 4;
    }
    for(int o=0;o<tt;o++){
        int k=arr[0];
        for(int i=0;i<len;i++){
            arr[i]=arr[i+1];
        }
        arr[len]=k;
    }
    int r=0;
    for(int i=0;i<=len;i++){
        r+=arr[i]*myPow(10,i);
    }
    delete arr;
    return r;
}
int ci(int n)
{
    return ceil(log10(n));
}
int* toArr(int n)
{
    int* r=new int();
    int i=0;
    while(n!=0){
        r[i]=n%10;
        n/=10;
        i++;
    }
    return r;
}
void init()
{
    const int NN = 10000000;
    tab= new bool[NN]();
    for(int i=0;i<NN;i++) tab[i]=false;
    for(int i=2;i<NN;i++) if(!tab[i]) for(int j=2*i;j<N;j+=i) tab[j]=true;
}
bool isPrime(int n)
{
    return !tab[n];
}
int myPow(int x, int p)
{
  if (p == 0) return 1;
  if (p == 1) return x;

  int tmp = myPow(x, p/2);
  if (p%2 == 0) return tmp * tmp;
  else return x * tmp * tmp;
}
