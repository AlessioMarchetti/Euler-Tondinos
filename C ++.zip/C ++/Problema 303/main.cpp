#include <iostream>
#define N 10000

using namespace std;

bool isok(long long); //Verifica che il numero abbia tutte le cifre minuori o uguali a 2
long long fn(long long); //calcola f(n)/n

int main()
{
    unsigned long long res=0;//Qui ci sar� il risultato
    for(long long i=1;i<=N;i++){
         res+=fn(i);
         if(i%500==0) cout<<i<<endl; //Stampa ogni tanto giusto per vedere l'avanzamento
    }
    cout<<res;
    return 0;
}
long long fn(long long n)
{
    long long k=1;
    while(true){
        if(isok(k*n)) break;
        k++;
        cout<<""; //Non capisco perch�, ma se tolgo questa linea il programma si blocca
    }
    return k;
}
bool isok(long long n)
{
    bool b=true;
    while(n!=0&&b){
        b=n%10<=2;
        n/=10;
    }
    return b;
}
