#include <iostream>

using namespace std;

bool* tab;
int last;
void init(n);
bool isPrimeN(int);

int main()
{
    int k=3;
    int q;
    int p;
    while(true){
        q=0;
        while(2*q*q<k){
           p=k-2*q*q;
           if(isPrimeN){
                cout<<k;
                return 0;
           }
        }
        k+=2;
    }
}
bool isPrimeN(int n)
{
    if(n>last) init(3*n/2+1);
    return tab[n];
}
void init(int n)
{
    delete tab;
    tab=new bool();
    for(int i=0;i<n;i++)tab[i]=false;
    for(int i=2;i<n;i++) if(!tab[i]) for(int j=2*i;j<n;j+=i) tab[j]=true;
    for(int i=2;i<n;i++) tab[i]=!tab[i];
    last=n;
}
