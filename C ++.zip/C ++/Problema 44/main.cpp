#include <iostream>
#include <math.h>
#define N 10000
#define M 10

/*
Finished
Answer: 5482660
29/3/2016,0:02
*/

using namespace std;

int f(int);
bool isEl(int*,int);

int main()
{
    int pen[N];
    int nr=0;
    int fb,fj;
    for(int i=0;i<N;i++) pen[i]=f(i);
    for(int j=1;j<N;j++) for(int b=1;b<N;b++){
        if(j%100==0&&b==1) cout<<j<<endl;
        if(b>j) continue;
        fb=f(b);
        fj=f(j);
        if(isEl(pen,fb+fj)&&isEl(pen,fj+2*fb)){
            cout<<fj<<" "<<b<<" "<<j<<endl;
            nr++;
        }
        if(nr>=M) return 0;
    }
    return 1;
}

int f(int x)
{
    return x*(3*x-1)/2;
}
bool isEl(int* l,int n)
{
    for(int i=0;i<N;i++) if(l[i]==n) return true;
    return false;
}
