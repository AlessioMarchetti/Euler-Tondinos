type Frac = (Integer,Integer)

{-
Solved
Answer: 153
02/04/2016, 15:01
-}

symplify:: Frac-> Frac
symplify (_,0) = (1,0)
symplify (0,_) = (0,1)
symplify (a,b) = (div a k,div b k)
      where k = gcd a b

sm':: Frac->Frac->Frac
sm' (a,b) (c,d) = (a*(div k b)+c*(div k d),k)
      where k = lcm b d

sm::Frac->Frac->Frac
sm a b = symplify $ sm' a b

rec:: Frac->Frac
rec (a,b) = (b,a)

cont::[Integer]->[Frac]
cont [] = [(1,0)]
cont (x:xs) =  frc:nxt
      where nxt = cont xs
            frc = sm (x,1) (rec $ head nxt)

spa n = 1:(take (n-1) (repeat 2))

ok (a,b) = (length $ show a)>(length $ show b)

contR (x:xs) = x:(map (\z->sm z (-1,1)) xs)

res x = length $ filter ok (contR $ cont $ spa x)
