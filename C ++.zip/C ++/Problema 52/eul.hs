import Data.List

--Solved
--Answer: 142857
--01/04/2016, 20:36


--Controlla se hanno le stesse cifre
same:: Integer->Integer->Bool
same a b = (sort $ show a) == (sort $ show b)

sameL:: [Integer]->Bool
sameL [_] = True
sameL (x:xs@(y:_)) = (same x y) && sameL xs

ok:: Integer -> Bool
ok n = sameL $ map (\x->n*x) [1..6]

my::Integer->Integer
my n = if ok n then n else my (n+1)

main=putStrLn(show $ my 1)
