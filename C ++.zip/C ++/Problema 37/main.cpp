#include <iostream>
#include "eul.h"

/*
Solved
Answer: 748317
29/3/2016, 22:18
*/

using namespace std;

short* rmL(short*,int);
short* rmR(short*,int);
bool prime(long);

int main()
{
    int nmb=0;
    long sum=0;
    long n=10;
    short* s=new short[1];
    short* q=new short[1];
    int ln;
    int ln1;
    bool ok;

    while(nmb<11){
        n++;
//        if(n%10000==0) cout<<"\t"<<n<<endl;
        ln=len(n);
        delete [] s;
        s=conv(n,ln);
        ok=true;
        delete [] q;
        q=s;
        ln1=ln;
        for(int i=0;i<ln;i++){
            ok&=prime(recompose(q,ln1));
            q=rmL(q,ln1);
            ln1--;
        }
        if(!ok) continue;
        delete [] q;
        q=s;
        ln1=ln;
        for(int i=0;i<ln;i++){
            ok&=prime(recompose(q,ln1));
            q=rmR(q,ln1);
            ln1--;
        }
        if(!ok) continue;
        cout<<nmb+1<<". "<<n<<endl;
        sum+=n;
        nmb++;
    }
    cout<<"\nResult: "<<sum;
    return 0;
}
short* rmL(short* s,int n)
{
    short* r=new short[n-1];
    for(int i=0;i<n-1;i++) r[i]=s[i+1];
    return r;
}
short* rmR(short* s,int n)
{
    short* r=new short[n-1];
    for(int i=0;i<n-1;i++) r[i]=s[i];
    return r;
}
bool prime(long m)
{
    const long N=10000000;
    static bool nu[N];
    static bool first=true;
    if(first){
        for(long i=0;i<=N;i++)nu[i]=true;
        for(long i=2;i<=N;i++) if(nu[i]) for(long j=2*i;j<=N;j+=i) nu[j]=false;
        nu[0]=0;
        nu[1]=0;
        first=false;
    }
    return nu[m];
}
