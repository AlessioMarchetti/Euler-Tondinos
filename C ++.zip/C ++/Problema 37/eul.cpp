#include "eul.h"
#include <math.h>

bool* genPrimeTab(long n)
{
    bool* nu = new bool[n];
    for(long i=0;i<=n;i++)nu[i]=true;
    for(long i=2;i<=n;i++) if(nu[i]) for(long j=2*i;j<=n;j+=i) nu[j]=false;
    nu[0]=0;
    nu[1]=0;
    return nu;
}
bool isPrime(long n)
{
    bool* nu=genPrimeTab(n);
    bool r=nu[n];
    delete [] nu;
    return r;
}
short* conv(long n,int N)
{
    short* s=new short[N];
    int i=0;
    while(n>0){
        s[i]=n%10;
        n/=10;
        i++;
    }
    return s;
}
long mPow(int x, int p)
{
  if (p == 0) return 1;
  if (p == 1) return x;

  long tmp = mPow(x, p/2);
  if (p%2 == 0) return tmp * tmp;
  else return x * tmp * tmp;
}
int len(long n)
{
    return log10(n)+1;
}
bool isSquare(int n)
{
    float c=sqrt(n);
    return c==ceil(c);
}
bool isPal(short* s,int n)
{
    for(int i=0;i<n/2+1;i++){
        if(s[i]!=s[n-i]) return false;
    }
    return true;
}
short* rev(short* s,int n)
{
    short* q=new short[n]();
    for(int i=0;i<=n;i++) q[i]=s[n-i];
    return q;
}
long recompose(short* s,int n)
{
    long res=0;
    for(int i=0;i<n;i++) res+=s[i]*mPow(10,i);
    return res;
}
