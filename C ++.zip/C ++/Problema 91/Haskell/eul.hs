import Data.List
type Point = (Int, Int)
type Tri = (Point, Point, Point)
range = [0..50]
grid = [(x,y) | x <- range, y <- range]
allTri = [((0,0),a,b) | a <- grid, b <- grid, not $ (a == (0,0)), not (b == (0,0)), not $ a == b]

--Solved
--Answer: 14234
--01/04/2016, 20:07

--Lunghezza dei lati al quadrato
sides:: Tri -> [Int]
sides (a,b,c) = sort [dist a b, dist b c, dist a c]

--Distanza al quadrato
dist::Point->Point->Int
dist (x1,y1) (x2,y2) = (x1-x2)^2 + (y1-y2)^2

--Check se un triangolo è rettangolo
isRect:: Tri-> Bool
isRect t = l1+l2==l3
      where [l1,l2,l3] = sides t

start:: [Tri] -> Int
start [] = 0
start (x:xs) = if isRect x then next+1 else next
      where next = start xs

res = start allTri

main=putStrLn(show $ div res 2)

ttt=filter isRect allTri
