--Solved
--Answer: 249
--31/3/2016, 17:26

isLy:: Integer->Int->Bool
isLy n 0 = True
isLy n k = if n+p==pal(n+p) then False else isLy (p+n) (k-1)
      where p = pal n

pal::Integer->Integer
pal n = read $ reverse $ show n

res:: Integer-> [Integer]
res 0 = []
res n = if isLy n 50 then n:r else r
      where r = res (n-1)

main=putStrLn(show $ length $ res 10000)
