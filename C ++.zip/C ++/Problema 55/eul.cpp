#include "eul.h"
#include <math.h>
#include <iostream>
using namespace std;

bool* genPrimeTab(long n)
{
    bool* nu = new bool[n]();
    for(long i=0;i<=n;i++)nu[i]=true;
    for(long i=2;i<=n;i++) if(nu[i]) for(long j=2*i;j<=n;j+=i) nu[j]=false;
    nu[0]=0;
    nu[1]=1;
    return nu;
}
bool isPrime(long n)
{
    return genPrimeTab(n)[n];
}
short* conv(unsigned long long n,int N)
{
    short* s=new short[13];
    int i=0;
    while(n>0){
        s[i]=n%10;
        n/=10;
        i++;
    }
    return s;
}
unsigned long long mPow(int x, int p)
{
  if (p == 0) return 1;
  if (p == 1) return x;

  unsigned long long tmp = mPow(x, p/2);
  if (p%2 == 0) return tmp * tmp;
  else return x * tmp * tmp;
}
int len(unsigned long long n)
{
    return log10(n)+1;
}
bool isSquare(int n)
{
    float c=sqrt(n);
    return c==ceil(c);
}
bool isPal(short* s,int n)
{
    for(int i=0;i<n;i++){
        if(s[i]!=s[n-i-1]){
            return false;
        }
    }
    return true;
}
short* rev(short* s,int n)
{
    short* q=new short[n]();
    for(int i=0;i<=n;i++) q[i]=s[n-i];
    return q;
}
unsigned long long pal(unsigned long long n,int k)
{
    short* s=new short[k];
    short* q=conv(n,k);
    for(int i=0;i<k;i++) s[i]=q[k-i-1];
    delete [] q;
    unsigned long long r=recom(s,k);
    delete [] s;
    return r;
}
unsigned long long recom(short* s,int l)
{
    unsigned long long r=0;
    for(int i=0;i<l;i++) r+=s[i]*mPow(10,i);
    return r;
}
