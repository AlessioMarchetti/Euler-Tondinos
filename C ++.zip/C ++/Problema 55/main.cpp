#include <iostream>
#include "eul.h"

using namespace std;

int main()
{
    int cnt=0;
    int n;
    unsigned long long m,pl;
    int ln;
    int i;
    short* s;
    bool bo;

    for(n=196;n<10000;n++){
        m=n;
        for(i=0;i<50;i++){
            ln=len(m);
            pl=pal(m,ln);
            pl+=m;
            ln=len(pl);
            short* s=conv(pl,ln);
            bo=isPal(s,ln);
            delete [] s;
            if(bo){
                cout<<pl<<endl;
                break;
            }
            m=pl;
        }
        if(i==49){
            cout<<n<<"\tIt's a Lychrel number, you dummy!"<<endl;
            cnt++;
        }
    }

    cout<<cnt;
    return 0;
}
