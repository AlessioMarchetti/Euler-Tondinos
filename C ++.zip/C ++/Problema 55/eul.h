#ifndef EUL_H
#define EUL_H

bool* genPrimeTab(long);
bool isPrime(long);
short* conv(unsigned long long,int);
bool isPal(short*,int);
bool isSquare(int);
int len(unsigned long long);
unsigned long long mPow(int,int);
short* rev(short*,int);
unsigned long long pal(unsigned long long,int);
unsigned long long recom(short*,int);


#endif
