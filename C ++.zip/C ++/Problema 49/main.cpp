#include <iostream>

using namespace std;
bool isPrime(int);
short** pts(short*);
short* conv(int);
int* all(int);
int myPow(int,int);

/*
This problem is finished.
Answer: 296962999629
28/3/2016, 21:36
*/


int main()
{
    int res[3];
    int run=0;
    for(int i=1000;i<10000;i++){//i numeri sono i, a[j], c;
        cout<<i<<endl;
        if(!isPrime(i)) continue;
        int* a=all(i);
        for(int j=0;j<24;j++){
            if(i==a[j]) continue;
            if(!isPrime(a[j])) continue;
            int c=2*a[j]-i;
            if(!isPrime(c)) continue;
            bool ok=false;
            for(int y=0;y<24;y++) ok|=a[y]==c;
            if(!ok) continue;
            res[0]=i;
            res[1]=a[j];
            res[2]=c;
            run++;
            break;
        }
        delete a;
        if(run==2) break;
    }
    cout<<"\n\n\n"<<res[0]<<endl<<res[1]<<endl<<res[2];
    return 0;
}
int* all(int n)
{
    int* r=new int();
    short** s=pts(conv(n));
    for(int i=0;i<24;i++){
        int k=0;
        for(int j=0;j<4;j++){
            k+=s[i][j]*myPow(10,j);
        }
        if(k<1000) k*=10;
        r[i]=k;
    }
    delete s;
    return r;
}
bool isPrime(int n)
{
    static bool* nu={0};
    static int l=0;

    if(n>=l){
        int N=3*n/2+1;
        l=N;
        delete nu;
        nu=new bool[N]();
        for(int i=0;i<N;i++)nu[i]=false;
        for(int i=2;i<N;i++) if(!nu[i]) for(int j=2*i;j<N;j+=i) nu[j]=true;
        return isPrime(n);
    }
    return !nu[n];
}
short** pts(short* a)
{
    short** r=new short*[24]();
    int f[24]={1234,1243,1324,1342,1423,1432,
            2134,2314,2341,2143,2431,2413,
            3124,3142,3241,3214,3412,3421,
            4123,4231,4132,4213,4312,4321};
    short* g;
    for(int i=0;i<24;i++){
        r[i]=new short[4]();
        g=conv(f[i]);
        for(int j=0;j<4;j++){
            r[i][j]=a[g[j]-1];
        }
//        delete g;
    }
    return r;
}

short* conv(int n)
{
    short* r=new short();
    for(int i=0;i<4;i++){
        r[i]=n%10;
        n/=10;
    }
    return r;
}
int myPow(int x, int p)
{
  if (p == 0) return 1;
  if (p == 1) return x;

  int tmp = myPow(x, p/2);
  if (p%2 == 0) return tmp * tmp;
  else return x * tmp * tmp;
}
