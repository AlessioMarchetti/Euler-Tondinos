#include <iostream>

using namespace std;

bool* prod(bool*,bool*,int);
bool isPrimeN(int);


int main()
{
    int z=1001;
    bool* g=new bool[z]();
    g[0]=0;
    g[1]=0;
    for(int i=2;i<z;i++){
        if(isPrimeN(i)) g[i]=0;
        else g[i]=1;
    }
    bool* a=new bool[z]();
    for(int i=0;i<z;i++) a[i]=0;
    a[0]=1;
    int r=0;
    for(int i=0;i<z;i++){
        a=prod(a,g,z);
        for(int j=0;j<z;j++){
            r+= a[j];
        }
    }
    cout<<endl<<r;
    return 0;
}

bool* prod(bool* a,bool* b,int n)
{
    bool* r = new bool[n]();
    for(int i=0;i<n;i++) r[i]=0;
    for(int i=0;i<n;i++) for(int j=0;j<n;j++){
        if(i+j>n) break;
        r[i+j]|=a[i]&b[j];
    }
    return r;
}
bool isPrimeN(int n)
{
    static bool* nu={0};
    static int l=0;

    if(n>=l){
        int N=3*n/2+1;
        l=N;
        delete nu;
        nu=new bool[N]();
        for(int i=0;i<N;i++)nu[i]=false;
        for(int i=2;i<N;i++) if(!nu[i]) for(int j=2*i;j<N;j+=i) nu[j]=true;
        return isPrimeN(n);
    }
    return nu[n];
}
