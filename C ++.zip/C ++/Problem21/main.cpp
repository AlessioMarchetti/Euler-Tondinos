#include <iostream>
#include <math.h>
using namespace std;

bool sq(int);
int* fer(int);
void st(int);
void cl();
int** sc(int*);
int* ord(int*);
int* di(int**);

int c;
int* p;

int main()
{
    cl();
    st(10000);
    ord(p);
    int** a=sc(p);
    int* b=di(a);
    b=ord(b);
    int m=1;
    while(b[m]!=-1) m++;
    for(int i=0;i<m;i++) cout<<b[i]<<endl;
    return 0;
}
int* di(int** l)
{
    int n=1;
    while(l[n]!=NULL) n++;
    int* r=new int[(*l)[1]];
    if(n==1){
        for(int i=0;i<=(*l)[1];i++){
            r[i]=pow((*l)[0],i);
            r[i+1]=-1;
        }
        return r;
    }
    int v=0;
    for(int i=0;i<=(*l)[1];i++){
        int* ne=di(l+1);
        int k=1;
        while(ne[k]!=-1)k++;
        for(int j=0;j<k;j++){
            r[v]=(pow(**l,i))*ne[j];
            v++;
        }
    }
    r[v]=-1;
    return r;
}
int** sc(int* u)
{
    int* l=u;
    int** res;
    res=new int*;
    *res=NULL;
    int h=0;
    int n=1;
    while(l[n]!=-1) n++;
    int k=-1;
    int* p;
    for(int i=0;i<n;i++){
        if(l[i]==k){
            p[1]++;
        }else{
            k=l[i];
            p = new int[2];
            p[0]=k;
            p[1]=1;
            res[h]=p;
            h++;
            res[h]=NULL;
        }
    }
    return res;
}
int* ord(int* l)
{
    int* k=l;
    int n=1;
    while(k[n]!=-1) n++;
    for(int i=0;i<n-1;i++){
        int* s;
        int m=INT_MAX;
        for(int j=0;j<n;j++) if(k[j]<m){
            m=k[j];
            s=k+j;
        }
        int t=*s;
        *s=*k;
        *k=t;
        k++;
        n--;
    }
    return l;
}
void cl()
{
    delete p;
    c=0;
    p=new int(-1);
}
void st(int n)
{
    int* r=fer(n);
    int a=r[0];
    int b=r[1];
    if(b==1){
        p[c]=a;
        p[c+1]=-1;
        c++;
        return;
    }
    st(a);
    st(b);
}
bool sq(int i)
{
    double d=sqrt(i);
    int j=d;
    return j==d;
}
int* fer(int n)
{
    int* r = new int[2];
    if(n%2==0){
        r[0]=2;
        r[1]=n/2;
        return r;
    }
    int a=sqrt(n)-1;
    int b;
    do{
        a++;
        b=a*a-n;
    }while(!sq(b));
    b=sqrt(b);
    r[0]=a+b;
    r[1]=a-b;
    return r;
}
