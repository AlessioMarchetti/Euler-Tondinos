#include <iostream>
#include <math.h>

/*
Solved
Answer: 40730
29/3/2016,00:34
*/

using namespace std;

long fac(short);
short* conv(long,int);


int main()
{

    long res=0;
    long s;
    short* c;
    int l;
    for(long i=3;i<2520000;i++){
        if(i%1000==0) cout<<i<<endl;
        s=0;
        l=(int) log10(i)+1;
        c=conv(i,l);
        for(int j=0;j<l;j++){
            s+=fac(c[j]);
        }
        if(s==i){
            res+=i;
            cout<<i<<endl;
        }
    }
    cout<<endl<<res;
    return 0;
}
long fac(short m)
{
    long n=(long) m;
    if(n==0) return 1;
    return n*fac(n-1);
}
short* conv(long n, int l)
{
    static short* r=new short();
    for(int i=0;i<l;i++){
        r[i]=n%10;
        n/=10;
    }
    return r;
}
