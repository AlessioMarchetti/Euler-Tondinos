#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream>
#define N 2345789
using namespace std;

long long* fermat(long long);
bool isSquare(long long);
void start(long long);

int main()
{
    start(N);
}

void start(long long n)
{
    long long* a = fermat(n);
    cout << a[0] << "\t" << a[1] << endl;
}

bool isSquare(long long n)
{
    double s = sqrt(n);
    return static_cast<long long>(s)==s;
}

long long* fermat(long long n)
{
    if(n==1)return nullptr;
    long long res[2];
    long long a = sqrt(n);
    long long b2;
    do{
        a++;
        b2 = a*a-n;
        //cout << "Checked " << a << "\t" << sqrt(n) << endl;
    }while(!isSquare(b2));
    long long b = sqrt(b2);
    res[0]=a+b;
    res[1]=a-b;
    return res;
}
