mx=7

possD = filter (not . isSquare) [1..mx]

isSquare:: Int->Bool
isSquare n = sq * sq == n
    where sq = floor $ sqrt $ (fromIntegral n::Double)

isX:: Int -> Int -> Bool
isX d x = (((rem (x+1) d) == 0)||((rem (x-1) d) == 0))&&(isSquare $ div (x*x-1) d)

minX:: Int ->Int
minX d = head [x | x <- [2..], isX d x]

maxVal = maximum $ map minX possD
res = snd $ head $ (filter (\x->(fst x)==maxVal)) $ map (\x->(minX x,x)) possD
