#include <iostream>
#define N 1000

using namespace std;

int tri(int);

int main()
{
    int m=0;
    int r=0;
    int t;
    for(int i=1;i<=N;i++){
        t=tri(i);
        if(t>m){
            m=t;
            r=i;
        }
    }
    cout<<r;
    return 0;
}

int tri(int n)
{
    int r=0;
    int a,b,c;
    for(a=1;a<=n;a++) for(b=1;b<=n;b++){
        c=n-a-b;
        if(a>c||b>c||a>b) continue;
        if(a*a+b*b==c*c) r++;
    }
    return r;
}
