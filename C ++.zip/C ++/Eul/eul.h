#ifndef EUL_H
#define EUL_H

bool* genPrimeTab(long);
bool isPrime(long);
short* conv(long,int);
bool isPal(short*,int);
bool isSquare(int);
int len(long);
long mPow(int,int);
short* rev(short*,int);


#endif
