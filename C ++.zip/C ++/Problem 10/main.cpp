#include <iostream>

#define N 2000000

using namespace std;


int main()
{
    bool nu[N];
    for(long i=0;i<N;i++)nu[i]=false;
    for(long i=2;i<N;i++) if(!nu[i]) for(long j=2*i;j<N;j+=i) nu[j]=true;
    long long res=0;
    for(long i=2;i<N;i++) if(!nu[i]) res+=i;
    cout << res;
    return 0;
}

