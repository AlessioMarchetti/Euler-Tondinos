pen = map (\x->div (x*(3*x-1)) 2) [1..]
n=1000

res=[fa-fb | fa<-pen,fb<-pen,fa>fb,elem (fa+fb) pen, elem (fa-fb) pen]

main=putStr(show res)
