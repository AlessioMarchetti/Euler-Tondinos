#include <iostream>

int main()
{
    string a = "1234";
    int n = sizeof(a);
    int* num = new int[n];
    for(int i=0;i<n;i++) num=(a[i]-48);
    for(int i=0;i<n;i++) cout<<num[i]<<endl;
    return 0;
}
