#include <iostream>
#include <math.h>

using namespace std;

bool pal(int);

int main()
{
    int k;
    int* li = new int[8100];
    int c = 0;
    for(int i = 999; i > 100; i--){
        for(int j = 999; j > 100; j--){
            k = i*j;
            if(pal(k)){
                li[c] = k;
                c++;
            }
        }
    }
    int m = li[0];
    for(int i=1;i<8100;i++){
        if(li[i] > m) m=li[i];
    }
    cout << m;

    return 0;
}

bool pal(int n)
{
    bool res = true;
    int ncf = ceil(log10(n));
    short* ch = new short[ncf];
    for(int i=0;i<ncf;i++){
        ch[i] = n%10;
        n/=10;
    }
    for(int i=0;i<ncf;i++) res &= ch[i] == ch[ncf-i-1];
    return res;
}
