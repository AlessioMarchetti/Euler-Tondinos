#ifndef EUL_H
#define EUL_H

bool* genPrimeTab(long);
bool isPrime(long);
short* conv(long);
bool isPal(short*,int);
bool isSquare(int);
int len(long);
short* rev(short*,int);
long mPow(int,int);

#endif
