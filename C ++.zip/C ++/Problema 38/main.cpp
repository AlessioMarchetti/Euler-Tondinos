#include <iostream>
#include "eul.h"

#define OUT 2
#define OK 1
#define LESS 0

/*
Solved
Answer: 932718654
29/3/2016, 20:44
*/

using namespace std;

short testPan(short*);

int main()
{
    long p;
    short flag;
    short* ls=new short[9];
    short cnt;
    short k;
    int ln;
    short* cv =new short[9];

    for(int i=10;i<10000;i++){
        delete [] ls;
        ls=new short[9];
        for(int y=0;y<9;y++) ls[y]=0;
        k=1;
        cnt=0;
        p=0;
        while(k<5){
            p=k*i;
            ln=len(p);
            delete [] cv;
            cv=rev(conv(p),ln-1);
            bool go=true;
            for(int j=0;j<ln;j++){
                if(cv[j]==0){
                     go=false;
                     break;
                }
                ls[cnt]=cv[j];
                cnt++;
            }
            if(!go) break;
            flag=testPan(ls);
            k++;
            if(flag==LESS) continue;
            if(flag==OUT) break;
            for(int i=0;i<9;i++) cout<<ls[i];
            cout<<endl;
            break;
        }
    }
    return 0;
}

short testPan(short* s)
{
    bool ns[9];
    for(int i=0;i<9;i++) ns[i]=0;
    for(int i=0;i<9;i++){
        if(s[i]==0) continue;
        if(ns[s[i]-1]) return OUT;
        ns[s[i]-1]=1;
    }
    for(int i=0;i<9;i++) if(!ns[i]) return LESS;
    return OK;
}
