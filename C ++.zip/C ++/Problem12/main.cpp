#include <iostream>
#include <math.h>
#define K 500

using namespace std;

int nump(int);
int tri(int);

int main()
{
    for(int i=0;true;i++){
        int x=nump(tri(i));
        cout<<i<<"\t"<<tri(i)<<"\t\t"<<x<<endl;
        if(x>K){
            cout << tri(i);
            return 0;
        }
    }
    return 0;
}
int tri(int n)
{
    return n*(n+1)/2;
}
int nump(int n)
{
    int r=0;
    for(int i=1;i<n;i++) if(n%i==0) r++;
    return r;
}
