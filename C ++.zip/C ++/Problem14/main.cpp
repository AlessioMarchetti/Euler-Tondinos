#include <iostream>
#define N 1000000

using namespace std;
unsigned long long rec(unsigned long long);
unsigned long long pass(unsigned long long);

int main()
{
    unsigned long long m=0;
    int start;
    for(int i=1;i<N;i++){
        unsigned long long p=pass(i);
        if(p>m){
            m=p;
            start=i;
        }
        cout << i << "\t" << p << "\t" << m <<endl;
    }
    cout << start;
    return 0;
}
unsigned long long pass(unsigned long long n)
{
    unsigned long long c=0;
    do{
        n=rec(n);
        c++;
    }while(n!=1);
    return c;
}
unsigned long long rec(unsigned long long n)
{
    if(n%2==0) return n/2;
    return 3*n+1;
}
