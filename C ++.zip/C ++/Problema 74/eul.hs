next::Integer->Integer
next n = sum $ map (\x-> fac $ read [x]) (show n)

fac::Integer->Integer
fac 0 = 1
fac n = n * fac (n-1)

chain:: Integer -> [Integer] -> [Integer]
chain n ns = if elem n ns then ns else chain nn (n:ns)
      where nn = next n

ok:: Integer->Int
ok n = length (chain n [])


res = length $ (filter (\x->x==60)) $ map (\x->ok x) [1..1000000]
