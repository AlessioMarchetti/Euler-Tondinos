#include <iostream>

#define N 10001

using namespace std;

int next(int*,int);

int main()
{
    int primes[N];
    for(int i=0;i<N;i++) primes[i]=-1;
    primes[0]=2;
    for(int i=1;i<N;i++){
        primes[i]=next(primes,i);
    }
    return 0;
}

int next(int* pr,int n)
{
    bool r;
    int k=pr[n-1];
    do{
        k++;
        r=true;
        for(int i=0;i<n;i++) r&=(k%pr[i]!=0);
    }while(!r);
    cout << k <<endl;
    return k;
}
